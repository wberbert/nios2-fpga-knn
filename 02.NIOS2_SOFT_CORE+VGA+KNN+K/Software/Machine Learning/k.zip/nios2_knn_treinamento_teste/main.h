#include <stdio.h>
#include <stdio_ext.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>

int fnc_treinar(void);
int fnc_testar(void);
int fnc_calcular_distancia_euclidiana(void);
int fnc_ordenar(void);
int fnc_obter_k_proximos(void);
